import React from 'react';
import { StylePreferencesProvider } from './context/StylePreferencesContext';
import { useAuthStore } from './stores/authStore';
import AuthPage from './components/auth/AuthPage';
import LandingPage from './components/LandingPage';
import MainApp from './components/MainApp';
import MobileNavigation from './components/MobileNavigation';

function App() {
  const { isAuthenticated, user } = useAuthStore();
  const [selectedSection, setSelectedSection] = React.useState<string | null>(null);

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  if (!selectedSection) {
    return <LandingPage onSectionSelect={setSelectedSection} />;
  }

  return (
    <StylePreferencesProvider>
      <div className="min-h-screen flex flex-col">
        <MainApp initialSection={selectedSection} />
        <MobileNavigation activeSection={selectedSection} onSectionChange={setSelectedSection} />
      </div>
    </StylePreferencesProvider>
  );
}

export default App;