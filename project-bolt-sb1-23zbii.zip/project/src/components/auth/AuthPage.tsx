import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp, Github, Loader2, Mail } from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import LoginForm from './LoginForm';
import SignupForm from './SignupForm';

const backgroundImages = [
  'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1920&q=80',
  'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=1920&q=80',
  'https://images.unsplash.com/photo-1531895861208-8504b98fe814?auto=format&fit=crop&w=1920&q=80'
];

const floatingBubbles = Array.from({ length: 15 }, (_, i) => ({
  id: i,
  size: Math.random() * 100 + 50,
  duration: Math.random() * 20 + 15,
  delay: Math.random() * 10,
  x: Math.random() * 100,
}));

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState(true);
  const [showMoreOptions, setShowMoreOptions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % backgroundImages.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSocialAuth = async (provider: string) => {
    setIsLoading(true);
    try {
      // Implement social auth logic here
      console.log(`Authenticating with ${provider}`);
    } catch (error) {
      console.error('Authentication failed:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen overflow-hidden relative flex">
      {/* Animated Background */}
      <div className="hidden lg:block lg:w-1/2 relative overflow-hidden">
        {/* Floating Bubbles */}
        {floatingBubbles.map((bubble) => (
          <motion.div
            key={bubble.id}
            className="absolute rounded-full bg-gradient-to-br from-white/20 to-white/5 backdrop-blur-sm"
            style={{
              width: bubble.size,
              height: bubble.size,
              left: `${bubble.x}%`,
            }}
            initial={{ y: '100vh' }}
            animate={{
              y: '-100vh',
            }}
            transition={{
              duration: bubble.duration,
              repeat: Infinity,
              delay: bubble.delay,
              ease: "linear"
            }}
          />
        ))}

        {/* Background Images */}
        <AnimatePresence initial={false}>
          <motion.img
            key={currentImageIndex}
            src={backgroundImages[currentImageIndex]}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7 }}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </AnimatePresence>

        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center px-12">
          <div className="max-w-md">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-bold text-white mb-4"
            >
              Descubra sua beleza única
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-white/90"
            >
              Personalize sua jornada de cuidados e estilo com recomendações exclusivas.
            </motion.p>
          </div>
        </div>
      </div>

      {/* Auth Form */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center px-6 py-12 bg-gradient-to-br from-violet-50 via-purple-50 to-blue-50">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md mx-auto space-y-8"
        >
          {/* Logo and Title */}
          <div className="text-center">
            <motion.h1 
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent"
            >
              Be.Beauty
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="mt-3 text-gray-600"
            >
              {isLogin ? 'Bem-vindo de volta!' : 'Crie sua conta'}
            </motion.p>
          </div>

          {/* Social Auth Buttons */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="space-y-3"
          >
            <button
              onClick={() => handleSocialAuth('google')}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-3 px-6 h-12 bg-white border border-gray-200 rounded-2xl hover:bg-gray-50 transition-all shadow-sm hover:shadow-md disabled:opacity-50"
            >
              <img src="/google.svg" alt="Google" className="w-5 h-5" />
              <span className="text-gray-700 font-medium">Continuar com Google</span>
            </button>

            <button
              onClick={() => handleSocialAuth('apple')}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-3 px-6 h-12 bg-black text-white rounded-2xl hover:bg-gray-900 transition-all shadow-sm hover:shadow-md disabled:opacity-50"
            >
              <img src="/apple.svg" alt="Apple" className="w-5 h-5" />
              <span className="font-medium">Continuar com Apple</span>
            </button>
          </motion.div>

          {/* Divider */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-200"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-gradient-to-br from-violet-50 via-purple-50 to-blue-50 text-gray-500">ou</span>
            </div>
          </div>

          {/* Auth Forms */}
          <AnimatePresence mode="wait">
            <motion.div
              key={isLogin ? 'login' : 'signup'}
              initial={{ opacity: 0, x: isLogin ? -20 : 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: isLogin ? 20 : -20 }}
              transition={{ duration: 0.3 }}
            >
              {isLogin ? <LoginForm /> : <SignupForm />}
            </motion.div>
          </AnimatePresence>

          {/* Toggle Auth Mode */}
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center text-gray-600"
          >
            {isLogin ? 'Não tem uma conta?' : 'Já tem uma conta?'}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="ml-2 text-violet-600 hover:text-violet-700 font-medium"
            >
              {isLogin ? 'Criar conta' : 'Entrar'}
            </button>
          </motion.p>

          {/* More Options */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <button
              onClick={() => setShowMoreOptions(!showMoreOptions)}
              className="w-full flex items-center justify-center gap-2 text-gray-500 hover:text-gray-600 py-2"
            >
              Mais opções de login
              {showMoreOptions ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </button>

            <AnimatePresence>
              {showMoreOptions && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-3 space-y-3 overflow-hidden"
                >
                  <button
                    onClick={() => handleSocialAuth('github')}
                    disabled={isLoading}
                    className="w-full flex items-center justify-center gap-3 px-6 h-12 bg-[#24292F] text-white rounded-2xl hover:bg-[#1a1f24] transition-all shadow-sm hover:shadow-md disabled:opacity-50"
                  >
                    <Github className="w-5 h-5" />
                    <span className="font-medium">Continuar com GitHub</span>
                  </button>

                  <button
                    onClick={() => handleSocialAuth('email')}
                    disabled={isLoading}
                    className="w-full flex items-center justify-center gap-3 px-6 h-12 bg-white border border-gray-200 rounded-2xl hover:bg-gray-50 transition-all shadow-sm hover:shadow-md disabled:opacity-50"
                  >
                    <Mail className="w-5 h-5" />
                    <span className="text-gray-700 font-medium">Continuar com Email</span>
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      </div>

      {/* Loading Overlay */}
      <AnimatePresence>
        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-white p-6 rounded-2xl flex items-center gap-4 shadow-xl"
            >
              <Loader2 className="w-6 h-6 animate-spin text-violet-600" />
              <span className="font-medium">Autenticando...</span>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}