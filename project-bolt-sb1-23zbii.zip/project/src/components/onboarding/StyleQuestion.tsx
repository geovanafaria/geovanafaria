import React from 'react';
import { ChevronRight } from 'lucide-react';

interface Option {
  id: string;
  label: string;
  image: string;
}

interface StyleQuestionProps {
  title: string;
  description: string;
  options: Option[];
  selectedOptions: string[];
  onSelect: (id: string) => void;
  onNext: () => void;
}

export default function StyleQuestion({
  title,
  description,
  options,
  selectedOptions,
  onSelect,
  onNext,
}: StyleQuestionProps) {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-gray-900 mb-2">{title}</h2>
      <p className="text-gray-600 mb-8">{description}</p>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {options.map((option) => (
          <button
            key={option.id}
            onClick={() => onSelect(option.id)}
            className={`relative aspect-square rounded-xl overflow-hidden group
              ${
                selectedOptions.includes(option.id)
                  ? 'ring-4 ring-pink-500'
                  : 'ring-1 ring-gray-200'
              }`}
          >
            <img
              src={option.image}
              alt={option.label}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-end p-4">
              <span className="text-white font-medium">{option.label}</span>
            </div>
          </button>
        ))}
      </div>

      <button
        onClick={onNext}
        disabled={selectedOptions.length === 0}
        className={`mt-8 w-full py-3 px-4 rounded-full flex items-center justify-center space-x-2
          ${
            selectedOptions.length > 0
              ? 'bg-black text-white hover:bg-gray-900'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
          }`}
      >
        <span>Next</span>
        <ChevronRight className="w-4 h-4" />
      </button>
    </div>
  );
}