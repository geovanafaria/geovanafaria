import React, { useState } from 'react';
import { useStylePreferences } from '../../context/StylePreferencesContext';
import StyleQuestion from './StyleQuestion';

const styleOptions = [
  {
    id: 'minimal',
    label: 'Minimal & Clean',
    image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'streetwear',
    label: 'Street Style',
    image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'classic',
    label: 'Classic & Elegant',
    image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'bohemian',
    label: 'Bohemian',
    image: 'https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'contemporary',
    label: 'Contemporary',
    image: 'https://images.unsplash.com/photo-1550614000-4895a10e1bfd?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'avant-garde',
    label: 'Avant-Garde',
    image: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80'
  }
];

const colorOptions = [
  {
    id: 'neutral',
    label: 'Neutral Tones',
    image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'monochrome',
    label: 'Monochrome',
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'bold',
    label: 'Bold Colors',
    image: 'https://images.unsplash.com/photo-1520006403909-838d6b92c22e?auto=format&fit=crop&w=800&q=80'
  }
];

const occasionOptions = [
  {
    id: 'casual',
    label: 'Casual',
    image: 'https://images.unsplash.com/photo-1523359346063-d879354c0ea5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'workwear',
    label: 'Work',
    image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'evening',
    label: 'Evening',
    image: 'https://images.unsplash.com/photo-1534445538923-ab38438550d2?auto=format&fit=crop&w=800&q=80'
  }
];

export default function Onboarding() {
  const { setPreferences, setHasCompletedOnboarding } = useStylePreferences();
  const [step, setStep] = useState(0);
  const [selectedStyles, setSelectedStyles] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedOccasions, setSelectedOccasions] = useState<string[]>([]);

  const handleComplete = () => {
    setPreferences({
      styleChoices: selectedStyles,
      colorPalette: selectedColors,
      occasions: selectedOccasions,
    });
    setHasCompletedOnboarding(true);
  };

  const steps = [
    {
      title: "What's your style?",
      description: "Choose the styles that resonate with you the most",
      options: styleOptions,
      selected: selectedStyles,
      setSelected: setSelectedStyles,
    },
    {
      title: "Color preferences",
      description: "Select the color palettes you prefer",
      options: colorOptions,
      selected: selectedColors,
      setSelected: setSelectedColors,
    },
    {
      title: "Occasions",
      description: "What occasions do you want to see outfits for?",
      options: occasionOptions,
      selected: selectedOccasions,
      setSelected: setSelectedOccasions,
    },
  ];

  const currentStep = steps[step];

  const handleNext = () => {
    if (step === steps.length - 1) {
      handleComplete();
    } else {
      setStep(step + 1);
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center">
      <StyleQuestion
        title={currentStep.title}
        description={currentStep.description}
        options={currentStep.options}
        selectedOptions={currentStep.selected}
        onSelect={(id) => {
          const current = currentStep.selected;
          const updated = current.includes(id)
            ? current.filter((item) => item !== id)
            : [...current, id];
          currentStep.setSelected(updated);
        }}
        onNext={handleNext}
      />
    </div>
  );
}