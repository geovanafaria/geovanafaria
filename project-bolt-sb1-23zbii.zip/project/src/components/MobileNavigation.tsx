import React from 'react';
import { Shirt, Scissors, Sparkles, Calendar } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const sections = [
  { id: 'fashion', label: 'Moda', icon: Shirt },
  { id: 'hair', label: 'Cabelo', icon: Scissors },
  { id: 'skin', label: 'Skin', icon: Sparkles },
  { id: 'calendar', label: 'Agenda', icon: Calendar },
];

const colorMap = {
  fashion: 'text-rose-500',
  hair: 'text-violet-500',
  skin: 'text-amber-500',
  calendar: 'text-emerald-500'
};

export default function MobileNavigation({ activeSection, onSectionChange }: NavigationProps) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t md:hidden">
      <div className="flex justify-around">
        {sections.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onSectionChange(id)}
            className={`flex flex-col items-center py-3 px-4 transition-colors
              ${activeSection === id 
                ? colorMap[id as keyof typeof colorMap]
                : 'text-gray-600'
              }`}
          >
            <Icon className="w-6 h-6 mb-1" />
            <span className="text-xs font-medium">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}