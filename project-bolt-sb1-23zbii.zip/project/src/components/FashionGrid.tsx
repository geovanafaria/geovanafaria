import React from 'react';
import FashionCard from './FashionCard';

const fashionItems = [
  {
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
    title: "Summer Chic Collection",
    author: "Sarah Style",
    likes: 2431
  },
  {
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80",
    title: "Urban Street Fashion",
    author: "Metro Fashion",
    likes: 1876
  },
  {
    image: "https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=800&q=80",
    title: "Vintage Vibes",
    author: "Retro Styles",
    likes: 3254
  },
  {
    image: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=800&q=80",
    title: "Minimalist Elegance",
    author: "Pure Fashion",
    likes: 1543
  },
  {
    image: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80",
    title: "Street Culture",
    author: "Urban Trends",
    likes: 2198
  },
  {
    image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80",
    title: "Bold & Beautiful",
    author: "Fashion Forward",
    likes: 2876
  }
];

export default function FashionGrid() {
  return (
    <div className="columns-1 sm:columns-2 lg:columns-3 xl:columns-4 gap-4 p-4">
      {fashionItems.map((item, index) => (
        <div key={index} className="mb-4 break-inside-avoid">
          <FashionCard {...item} />
        </div>
      ))}
    </div>
  );
}