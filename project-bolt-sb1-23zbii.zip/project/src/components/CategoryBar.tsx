import React from 'react';

const categories = [
  "For You",
  "Trending",
  "Street Style",
  "Minimalist",
  "Vintage",
  "Luxury",
  "Sustainable",
  "Accessories"
];

export default function CategoryBar() {
  return (
    <div className="border-b bg-white/80 backdrop-blur-md sticky top-[73px] z-40">
      <div className="max-w-7xl mx-auto px-4 py-3 overflow-x-auto">
        <div className="flex space-x-2">
          {categories.map((category, index) => (
            <button
              key={index}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-colors
                ${index === 0 
                  ? 'bg-black text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              {category}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}