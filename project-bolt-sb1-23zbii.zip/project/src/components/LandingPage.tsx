import React from 'react';
import { 
  Shirt, 
  Scissors, 
  Sparkles, 
  Calendar,
  ArrowRight,
  LogOut
} from 'lucide-react';
import { useAuthStore } from '../stores/authStore';

interface LandingPageProps {
  onSectionSelect: (section: string) => void;
}

const sections = [
  {
    id: 'fashion',
    title: 'Moda',
    description: 'Descubra seu estilo único e personalize seu feed de moda',
    icon: Shirt,
    color: 'violet',
    gradient: 'from-violet-500/20 to-violet-500/5'
  },
  {
    id: 'hair',
    title: 'Cabelo',
    description: 'Cuidados personalizados para seus fios',
    icon: Scissors,
    color: 'indigo',
    gradient: 'from-indigo-500/20 to-indigo-500/5'
  },
  {
    id: 'skin',
    title: 'Skin Care',
    description: 'Rotina personalizada para sua pele',
    icon: Sparkles,
    color: 'blue',
    gradient: 'from-blue-500/20 to-blue-500/5'
  },
  {
    id: 'calendar',
    title: 'Calendário',
    description: 'Organize sua rotina de cuidados',
    icon: Calendar,
    color: 'purple',
    gradient: 'from-purple-500/20 to-purple-500/5'
  }
];

const colorMap = {
  violet: {
    light: 'text-violet-600',
    hover: 'hover:bg-violet-50',
    border: 'border-violet-200',
    icon: 'bg-violet-600'
  },
  indigo: {
    light: 'text-indigo-600',
    hover: 'hover:bg-indigo-50',
    border: 'border-indigo-200',
    icon: 'bg-indigo-600'
  },
  blue: {
    light: 'text-blue-600',
    hover: 'hover:bg-blue-50',
    border: 'border-blue-200',
    icon: 'bg-blue-600'
  },
  purple: {
    light: 'text-purple-600',
    hover: 'hover:bg-purple-50',
    border: 'border-purple-200',
    icon: 'bg-purple-600'
  }
};

export default function LandingPage({ onSectionSelect }: LandingPageProps) {
  const { logout } = useAuthStore();

  const handleLogout = () => {
    if (confirm('Tem certeza que deseja sair?')) {
      logout();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-purple-50 to-blue-50">
      {/* Header */}
      <header className="pt-16 pb-12 text-center relative px-4">
        <button
          onClick={handleLogout}
          className="absolute right-4 top-4 flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sair</span>
        </button>

        <h1 className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
          Bem-vindo ao Be.Beauty
        </h1>
        <p className="mt-4 text-gray-600">
          Sua jornada personalizada de beleza e cuidados
        </p>
      </header>

      {/* Sections Grid */}
      <div className="max-w-7xl mx-auto px-4 pb-16">
        <div className="grid md:grid-cols-2 gap-6">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => onSectionSelect(section.id)}
              className={`group relative overflow-hidden rounded-2xl border bg-white/80 backdrop-blur-sm p-8 text-left transition-all
                ${colorMap[section.color].border}
                ${colorMap[section.color].hover}`}
            >
              {/* Background Gradient */}
              <div className={`absolute inset-0 opacity-40 bg-gradient-to-br ${section.gradient}`} />

              <div className="relative">
                {/* Icon */}
                <div className={`inline-flex p-3 rounded-xl ${colorMap[section.color].icon}`}>
                  <section.icon className="w-6 h-6 text-white" />
                </div>

                {/* Content */}
                <div className="mt-4">
                  <h2 className={`text-2xl font-semibold ${colorMap[section.color].light}`}>
                    {section.title}
                  </h2>
                  <p className="mt-2 text-gray-600">
                    {section.description}
                  </p>
                </div>

                {/* Arrow */}
                <div className="mt-4 flex items-center gap-2 text-sm font-medium">
                  <span className={colorMap[section.color].light}>
                    Começar
                  </span>
                  <ArrowRight className={`w-4 h-4 transition-transform group-hover:translate-x-1 ${colorMap[section.color].light}`} />
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}