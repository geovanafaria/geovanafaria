import React, { useState } from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';

interface SkinTypeQuizProps {
  onComplete: (profile: {
    type: string;
    concerns: string[];
    sensitivity: string;
  }) => void;
}

const questions = [
  {
    id: 'type',
    title: 'Como sua pele fica algumas horas após lavar o rosto?',
    options: [
      {
        id: 'dry',
        label: 'Seca e repuxando',
        image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'oily',
        label: 'Oleosa em toda extensão',
        image: 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'combination',
        label: 'Oleosa na zona T, normal nas bochechas',
        image: 'https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'normal',
        label: 'Normal, sem alterações significativas',
        image: 'https://images.unsplash.com/photo-1573461160327-b450ce3d8e7f?auto=format&fit=crop&w=800&q=80'
      }
    ]
  },
  {
    id: 'concerns',
    title: 'Quais são suas principais preocupações?',
    multiple: true,
    options: [
      {
        id: 'acne',
        label: 'Acne e Espinhas',
        image: 'https://images.unsplash.com/photo-1513531926349-466f15ec8cc7?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'aging',
        label: 'Sinais de Envelhecimento',
        image: 'https://images.unsplash.com/photo-1582616698198-f978da534162?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'dark-spots',
        label: 'Manchas Escuras',
        image: 'https://images.unsplash.com/photo-1515377905703-c4788e51af15?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'pores',
        label: 'Poros Dilatados',
        image: 'https://images.unsplash.com/photo-1505944270255-72b8c68c6a70?auto=format&fit=crop&w=800&q=80'
      }
    ]
  },
  {
    id: 'sensitivity',
    title: 'Sua pele é sensível?',
    options: [
      {
        id: 'very',
        label: 'Muito Sensível',
        description: 'Fica vermelha facilmente e reage a muitos produtos',
        image: 'https://images.unsplash.com/photo-1588619090674-13fa5c92f3b8?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'moderate',
        label: 'Moderadamente Sensível',
        description: 'Ocasionalmente fica irritada',
        image: 'https://images.unsplash.com/photo-1601049676869-702ea24cfd58?auto=format&fit=crop&w=800&q=80'
      },
      {
        id: 'not',
        label: 'Não Sensível',
        description: 'Raramente apresenta irritação',
        image: 'https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=800&q=80'
      }
    ]
  }
];

export default function SkinTypeQuiz({ onComplete }: SkinTypeQuizProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({
    type: '',
    concerns: [],
    sensitivity: ''
  });

  const currentQuestion = questions[currentStep];
  const isLastQuestion = currentStep === questions.length - 1;

  const handleAnswer = (value: string) => {
    if (currentQuestion.multiple) {
      setAnswers(prev => ({
        ...prev,
        [currentQuestion.id]: prev[currentQuestion.id].includes(value)
          ? prev[currentQuestion.id].filter((v: string) => v !== value)
          : [...prev[currentQuestion.id], value]
      }));
    } else {
      setAnswers(prev => ({
        ...prev,
        [currentQuestion.id]: value
      }));

      if (isLastQuestion) {
        onComplete({
          type: answers.type,
          concerns: answers.concerns,
          sensitivity: value
        });
      } else {
        setCurrentStep(prev => prev + 1);
      }
    }
  };

  const handleNext = () => {
    if (currentQuestion.multiple && answers[currentQuestion.id].length > 0) {
      if (isLastQuestion) {
        onComplete({
          type: answers.type,
          concerns: answers.concerns,
          sensitivity: answers.sensitivity
        });
      } else {
        setCurrentStep(prev => prev + 1);
      }
    }
  };

  const handleBack = () => {
    setCurrentStep(prev => prev - 1);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Progress bar */}
      <div className="mb-8">
        <div className="h-2 w-full bg-gray-200 rounded-full">
          <div
            className="h-full bg-amber-500 rounded-full transition-all duration-300"
            style={{ width: `${((currentStep + 1) / questions.length) * 100}%` }}
          />
        </div>
        <p className="text-sm text-gray-500 mt-2">
          Questão {currentStep + 1} de {questions.length}
        </p>
      </div>

      {/* Question */}
      <h2 className="text-2xl font-bold text-gray-900 mb-6">{currentQuestion.title}</h2>

      {/* Options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        {currentQuestion.options.map((option) => (
          <button
            key={option.id}
            onClick={() => handleAnswer(option.id)}
            className={`relative aspect-video rounded-xl overflow-hidden transition-all
              ${currentQuestion.multiple
                ? answers[currentQuestion.id].includes(option.id)
                  ? 'ring-4 ring-amber-500 scale-[1.02]'
                  : 'ring-1 ring-gray-200 hover:ring-amber-200'
                : answers[currentQuestion.id] === option.id
                  ? 'ring-4 ring-amber-500 scale-[1.02]'
                  : 'ring-1 ring-gray-200 hover:ring-amber-200'
              }`}
          >
            <img
              src={option.image}
              alt={option.label}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent flex flex-col justify-end p-4">
              <span className="text-white font-medium text-lg">{option.label}</span>
              {option.description && (
                <span className="text-white/80 text-sm">{option.description}</span>
              )}
            </div>
          </button>
        ))}
      </div>

      {/* Navigation */}
      <div className="flex justify-between">
        <button
          onClick={handleBack}
          disabled={currentStep === 0}
          className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all
            ${currentStep === 0
              ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
        >
          <ChevronLeft className="w-5 h-5" />
          Voltar
        </button>

        {currentQuestion.multiple && (
          <button
            onClick={handleNext}
            disabled={answers[currentQuestion.id].length === 0}
            className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all
              ${answers[currentQuestion.id].length > 0
                ? 'bg-black text-white hover:bg-gray-900'
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
              }`}
          >
            {isLastQuestion ? 'Finalizar' : 'Próximo'}
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}