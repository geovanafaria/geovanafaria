import React, { useState } from 'react';
import { Shield, Calendar, ExternalLink } from 'lucide-react';
import { useCalendarStore } from '../../stores/calendarStore';
import AddEventModal from '../calendar/AddEventModal';

interface SkinProduct {
  id: string;
  name: string;
  brand: string;
  price: number;
  rating: number;
  reviews: number;
  image: string;
  description: string;
  usage: string;
  frequency: string;
  marketplace: 'amazon' | 'google' | 'mercadolivre';
  marketplaceUrl: string;
}

interface SkinRecommendationsProps {
  profile: {
    type: string;
    concerns: string[];
    sensitivity: string;
  };
}

const mockProducts: SkinProduct[] = [
  {
    id: '1',
    name: 'Gel de Limpeza Facial',
    brand: 'CeraVe',
    price: 59.90,
    rating: 4.8,
    reviews: 1523,
    image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80',
    description: 'Gel de limpeza suave para pele sensível',
    usage: 'Manhã e noite',
    frequency: 'Diário',
    marketplace: 'amazon',
    marketplaceUrl: 'https://amazon.com'
  },
  {
    id: '2',
    name: 'Hidratante Facial',
    brand: 'La Roche-Posay',
    price: 89.90,
    rating: 4.7,
    reviews: 982,
    image: 'https://images.unsplash.com/photo-1556228722-bdbcd8b1ed58?auto=format&fit=crop&w=800&q=80',
    description: 'Hidratante não comedogênico para pele oleosa',
    usage: 'Após a limpeza',
    frequency: 'Diário',
    marketplace: 'google',
    marketplaceUrl: 'https://shopping.google.com'
  }
];

const skinTypeDescriptions = {
  dry: 'Sua pele precisa de hidratação intensa',
  oily: 'Sua pele precisa de controle de oleosidade',
  combination: 'Sua pele precisa de cuidados específicos para cada região',
  normal: 'Sua pele está equilibrada, mantenha os cuidados básicos'
};

export default function SkinRecommendations({ profile }: SkinRecommendationsProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<SkinProduct | null>(null);

  const handleAddToCalendar = (product: SkinProduct) => {
    setSelectedProduct(product);
    setShowAddModal(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">Suas Recomendações de Skincare</h2>
        <p className="text-gray-600">
          {skinTypeDescriptions[profile.type as keyof typeof skinTypeDescriptions]}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockProducts.map((product) => (
          <div
            key={product.id}
            className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow"
          >
            <div className="relative h-48">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            
            <div className="p-4">
              <div className="flex items-start justify-between gap-2">
                <h3 className="font-medium text-gray-900 line-clamp-2">{product.name}</h3>
                <span className="text-lg font-bold text-amber-600 whitespace-nowrap">
                  R$ {product.price.toFixed(2)}
                </span>
              </div>
              
              <p className="text-sm text-gray-500 mt-1">{product.brand}</p>
              <p className="text-sm text-gray-600 mt-2">{product.description}</p>
              
              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Shield className="w-4 h-4" />
                  <span>Uso: {product.usage}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span>Frequência: {product.frequency}</span>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <a
                  href={product.marketplaceUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-900 transition-colors"
                >
                  Comprar
                  <ExternalLink className="w-4 h-4" />
                </a>
                <button
                  onClick={() => handleAddToCalendar(product)}
                  className="flex items-center justify-center gap-2 px-4 py-2 border border-amber-500 text-amber-500 rounded-lg hover:bg-amber-50 transition-colors"
                >
                  Agendar Uso
                  <Calendar className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showAddModal && selectedProduct && (
        <AddEventModal
          selectedDate={new Date()}
          onClose={() => {
            setShowAddModal(false);
            setSelectedProduct(null);
          }}
          defaultValues={{
            title: `Usar ${selectedProduct.name}`,
            description: `Momento de usar ${selectedProduct.name} - ${selectedProduct.usage}`,
            category: 'skin'
          }}
        />
      )}
    </div>
  );
}