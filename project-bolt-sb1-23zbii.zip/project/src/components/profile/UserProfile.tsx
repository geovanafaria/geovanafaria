import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  User,
  Heart,
  Calendar,
  Settings,
  LogOut,
  X,
  Camera,
  Edit2,
} from 'lucide-react';
import { useAuthStore } from '../../stores/authStore';
import { useWishlistStore } from '../../stores/wishlistStore';
import WishlistGrid from './WishlistGrid';

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UserProfile({ isOpen, onClose }: UserProfileProps) {
  const { user, logout } = useAuthStore();
  const [activeTab, setActiveTab] = React.useState<'profile' | 'wishlist' | 'settings'>('profile');
  const wishlist = useWishlistStore((state) => state.items);

  const handleLogout = () => {
    if (confirm('Tem certeza que deseja sair?')) {
      logout();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="absolute right-0 top-0 bottom-0 w-full max-w-md bg-white shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-2xl font-bold">Seu Perfil</h2>
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Profile Header */}
            <div className="p-6 border-b">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center">
                    {user?.image ? (
                      <img
                        src={user.image}
                        alt={user.name}
                        className="w-full h-full rounded-full object-cover"
                      />
                    ) : (
                      <User className="w-8 h-8 text-gray-400" />
                    )}
                  </div>
                  <button className="absolute bottom-0 right-0 p-1.5 bg-black text-white rounded-full">
                    <Camera className="w-4 h-4" />
                  </button>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-semibold">{user?.name}</h3>
                    <button className="p-1 hover:bg-gray-100 rounded-full">
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-gray-600">{user?.email}</p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <div className="flex border-b">
              <button
                onClick={() => setActiveTab('profile')}
                className={`flex-1 py-4 text-center font-medium transition-colors
                  ${activeTab === 'profile'
                    ? 'text-pink-500 border-b-2 border-pink-500'
                    : 'text-gray-600 hover:text-gray-900'
                  }`}
              >
                Perfil
              </button>
              <button
                onClick={() => setActiveTab('wishlist')}
                className={`flex-1 py-4 text-center font-medium transition-colors
                  ${activeTab === 'wishlist'
                    ? 'text-pink-500 border-b-2 border-pink-500'
                    : 'text-gray-600 hover:text-gray-900'
                  }`}
              >
                Wishlist
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`flex-1 py-4 text-center font-medium transition-colors
                  ${activeTab === 'settings'
                    ? 'text-pink-500 border-b-2 border-pink-500'
                    : 'text-gray-600 hover:text-gray-900'
                  }`}
              >
                Configurações
              </button>
            </div>

            {/* Content */}
            <div className="p-6 overflow-y-auto" style={{ height: 'calc(100vh - 280px)' }}>
              {activeTab === 'profile' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Sobre</h4>
                    <p className="text-gray-600">
                      Configure seu perfil para receber recomendações personalizadas.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="text-lg font-semibold mb-2">Preferências</h4>
                    <div className="space-y-2">
                      <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50">
                        <span className="text-gray-700">Estilos Favoritos</span>
                        <span className="text-gray-400">4 selecionados</span>
                      </button>
                      <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50">
                        <span className="text-gray-700">Marcas Favoritas</span>
                        <span className="text-gray-400">6 selecionadas</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'wishlist' && (
                <WishlistGrid items={wishlist} />
              )}

              {activeTab === 'settings' && (
                <div className="space-y-4">
                  <button className="w-full flex items-center justify-between p-4 rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <Settings className="w-5 h-5 text-gray-500" />
                      <span>Configurações da Conta</span>
                    </div>
                  </button>
                  
                  <button className="w-full flex items-center justify-between p-4 rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <Calendar className="w-5 h-5 text-gray-500" />
                      <span>Preferências de Notificação</span>
                    </div>
                  </button>
                  
                  <button className="w-full flex items-center justify-between p-4 rounded-lg hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <Heart className="w-5 h-5 text-gray-500" />
                      <span>Gerenciar Wishlist</span>
                    </div>
                  </button>

                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center justify-between p-4 rounded-lg hover:bg-red-50 text-red-600"
                  >
                    <div className="flex items-center gap-3">
                      <LogOut className="w-5 h-5" />
                      <span>Sair</span>
                    </div>
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}