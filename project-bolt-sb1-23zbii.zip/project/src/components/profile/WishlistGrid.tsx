import React from 'react';
import { Trash2, ExternalLink } from 'lucide-react';
import { useWishlistStore } from '../../stores/wishlistStore';
import type { WishlistItem } from '../../stores/wishlistStore';

interface WishlistGridProps {
  items: WishlistItem[];
}

export default function WishlistGrid({ items }: WishlistGridProps) {
  const removeItem = useWishlistStore((state) => state.removeItem);

  if (items.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Sua wishlist está vazia</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-4">
      {items.map((wishlistItem) => {
        const item = wishlistItem.item;
        const isProduct = wishlistItem.type === 'product';

        return (
          <div
            key={wishlistItem.id}
            className="bg-white rounded-xl overflow-hidden shadow-md group"
          >
            <div className="relative aspect-square">
              <img
                src={item.image}
                alt={isProduct ? item.name : item.description}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button
                  onClick={() => removeItem(wishlistItem.id)}
                  className="p-2 bg-white/90 rounded-full hover:bg-white transition-colors"
                >
                  <Trash2 className="w-5 h-5 text-red-500" />
                </button>
                {isProduct && 'marketplaceUrl' in item && (
                  <a
                    href={item.marketplaceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 bg-white/90 rounded-full hover:bg-white transition-colors"
                  >
                    <ExternalLink className="w-5 h-5 text-gray-700" />
                  </a>
                )}
              </div>
            </div>
            <div className="p-3">
              <h3 className="font-medium text-sm line-clamp-1">
                {isProduct ? item.name : item.description}
              </h3>
              <p className="text-sm text-gray-500">
                {isProduct ? item.brand : item.brand}
              </p>
              {isProduct && 'price' in item && (
                <p className="text-sm font-bold text-pink-600 mt-1">
                  R$ {typeof item.price === 'number' ? item.price.toFixed(2) : item.price}
                </p>
              )}
            </div>
          </div>
        )
      })}
    </div>
  );
}