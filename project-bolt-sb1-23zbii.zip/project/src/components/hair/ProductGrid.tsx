import React, { useState } from 'react';
import { Sliders, Search } from 'lucide-react';
import ProductCard from './ProductCard';
import type { Product } from '../../types/Product';

interface ProductGridProps {
  products: Product[];
}

export default function ProductGrid({ products }: ProductGridProps) {
  const [sortBy, setSortBy] = useState<'price' | 'rating'>('rating');
  const [filterMarketplace, setFilterMarketplace] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  const filteredAndSortedProducts = products
    .filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          product.brand.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesMarketplace = filterMarketplace.length === 0 || 
                                filterMarketplace.includes(product.marketplace);
      return matchesSearch && matchesMarketplace;
    })
    .sort((a, b) => {
      if (sortBy === 'price') return a.price - b.price;
      return b.rating - a.rating;
    });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 relative">
          <input
            type="search"
            placeholder="Buscar produtos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-pink-500 focus:border-transparent"
          />
          <Search className="absolute left-3 top-2.5 text-gray-400 w-5 h-5" />
        </div>
        
        <div className="flex gap-2">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'price' | 'rating')}
            className="px-4 py-2 rounded-lg border border-gray-200 bg-white"
          >
            <option value="rating">Melhor Avaliados</option>
            <option value="price">Menor Preço</option>
          </select>
          
          <button
            onClick={() => {/* Toggle filters modal */}}
            className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50"
          >
            <Sliders className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredAndSortedProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}