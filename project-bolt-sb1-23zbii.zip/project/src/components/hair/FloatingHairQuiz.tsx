import React, { useState } from 'react';
import { Droplets } from 'lucide-react';

interface FloatingHairQuizProps {
  onSubmit: (condition: string) => void;
}

const conditions = [
  { id: 'hydrated', label: 'Hidratado', description: 'O fio afundou rapidamente' },
  { id: 'malnourished', label: 'Desnutrido', description: 'O fio ficou flutuando no meio' },
  { id: 'dry', label: 'Ressecado', description: 'O fio ficou flutuando na superfície' },
  { id: 'porous', label: 'Poroso', description: 'O fio afundou lentamente' }
];

export default function FloatingHairQuiz({ onSubmit }: FloatingHairQuizProps) {
  const [selectedCondition, setSelectedCondition] = useState('');
  const [showInstructions, setShowInstructions] = useState(true);

  if (showInstructions) {
    return (
      <div className="max-w-2xl mx-auto text-center space-y-6">
        <div className="bg-blue-50 p-8 rounded-2xl">
          <Droplets className="w-16 h-16 text-blue-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-4">Teste do Fio Flutuante</h2>
          <div className="space-y-4 text-left">
            <p className="text-gray-700">Para realizar este teste, você precisará:</p>
            <ol className="list-decimal list-inside space-y-2 text-gray-600">
              <li>Um copo transparente</li>
              <li>Água em temperatura ambiente</li>
              <li>Um fio de cabelo limpo</li>
            </ol>
            <p className="text-gray-700">Instruções:</p>
            <ol className="list-decimal list-inside space-y-2 text-gray-600">
              <li>Encha o copo com água</li>
              <li>Arranque um fio de cabelo limpo</li>
              <li>Coloque o fio na água</li>
              <li>Observe o comportamento do fio por 3-4 minutos</li>
            </ol>
          </div>
        </div>
        <button
          onClick={() => setShowInstructions(false)}
          className="bg-black text-white px-8 py-4 rounded-full hover:bg-gray-900 transition-colors"
        >
          Já realizei o teste
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">Como o fio se comportou?</h2>
        <p className="text-gray-600">Selecione o resultado que melhor corresponde ao seu teste</p>
      </div>

      <div className="grid gap-4">
        {conditions.map((condition) => (
          <button
            key={condition.id}
            onClick={() => setSelectedCondition(condition.id)}
            className={`p-6 rounded-xl text-left transition-all
              ${selectedCondition === condition.id
                ? 'bg-pink-50 ring-2 ring-pink-500'
                : 'bg-gray-50 hover:bg-gray-100'}`}
          >
            <h3 className="font-semibold text-lg mb-1">{condition.label}</h3>
            <p className="text-gray-600">{condition.description}</p>
          </button>
        ))}
      </div>

      <button
        onClick={() => selectedCondition && onSubmit(selectedCondition)}
        disabled={!selectedCondition}
        className={`w-full py-4 rounded-full text-center transition-all
          ${selectedCondition
            ? 'bg-black text-white hover:bg-gray-900'
            : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}
      >
        Ver Resultados
      </button>
    </div>
  );
}