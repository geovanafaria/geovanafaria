import React from 'react';
import { Star, ExternalLink } from 'lucide-react';
import type { Product } from '../../types/Product';

interface ProductCardProps {
  product: Product;
}

const marketplaceLogos = {
  amazon: '/marketplace-logos/amazon.svg',
  google: '/marketplace-logos/google.svg',
  mercadolivre: '/marketplace-logos/mercadolivre.svg'
};

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative h-48">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute top-2 right-2">
          <img
            src={marketplaceLogos[product.marketplace]}
            alt={product.marketplace}
            className="w-6 h-6"
          />
        </div>
      </div>
      
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-medium text-gray-900 line-clamp-2">{product.name}</h3>
          <span className="text-lg font-bold text-pink-600 whitespace-nowrap">
            R$ {product.price.toFixed(2)}
          </span>
        </div>
        
        <p className="text-sm text-gray-500 mt-1">{product.brand}</p>
        
        <div className="flex items-center gap-1 mt-2">
          <Star className="w-4 h-4 fill-current text-yellow-400" />
          <span className="text-sm font-medium">{product.rating.toFixed(1)}</span>
          <span className="text-sm text-gray-500">({product.reviews})</span>
        </div>

        <a
          href={product.marketplaceUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 w-full flex items-center justify-center gap-2 py-2 px-4 bg-black text-white rounded-lg hover:bg-gray-900 transition-colors"
        >
          Ver no {product.marketplace}
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    </div>
  );
}