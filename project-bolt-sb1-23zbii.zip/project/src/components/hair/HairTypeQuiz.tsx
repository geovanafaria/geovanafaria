import React, { useState } from 'react';

interface HairTypeQuizProps {
  onSubmit: (type: string, gender: string) => void;
}

const hairTypes = [
  { 
    id: 'straight', 
    label: 'Liso', 
    image: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=800&q=80'
  },
  { 
    id: 'wavy', 
    label: 'Ondulado', 
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80'
  },
  { 
    id: 'curly', 
    label: 'Cacheado', 
    image: 'https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=800&q=80'
  },
  { 
    id: 'coily', 
    label: 'Crespo', 
    image: 'https://images.unsplash.com/photo-1541421614-4c4c0530c274?auto=format&fit=crop&w=800&q=80'
  }
];

const genders = [
  { id: 'female', label: 'Feminino' },
  { id: 'male', label: 'Masculino' },
  { id: 'other', label: 'Outro' }
];

export default function HairTypeQuiz({ onSubmit }: HairTypeQuizProps) {
  const [selectedType, setSelectedType] = useState('');
  const [selectedGender, setSelectedGender] = useState('');

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">Qual é o seu tipo de cabelo?</h2>
        <p className="text-gray-600">Selecione a opção que melhor representa seu cabelo</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
        {hairTypes.map((type) => (
          <button
            key={type.id}
            onClick={() => setSelectedType(type.id)}
            className={`relative aspect-square rounded-xl overflow-hidden transition-all
              ${selectedType === type.id ? 'ring-4 ring-pink-500 scale-[1.02]' : 'ring-1 ring-gray-200'}`}
          >
            <img
              src={type.image}
              alt={type.label}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent flex items-end p-4">
              <span className="text-white font-medium text-lg">{type.label}</span>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold">Qual é o seu gênero?</h3>
        <div className="flex gap-4">
          {genders.map((gender) => (
            <button
              key={gender.id}
              onClick={() => setSelectedGender(gender.id)}
              className={`px-6 py-3 rounded-full transition-all
                ${selectedGender === gender.id
                  ? 'bg-pink-500 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
            >
              {gender.label}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={() => selectedType && selectedGender && onSubmit(selectedType, selectedGender)}
        disabled={!selectedType || !selectedGender}
        className={`w-full py-4 rounded-full text-center transition-all
          ${selectedType && selectedGender
            ? 'bg-black text-white hover:bg-gray-900'
            : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}
      >
        Continuar
      </button>
    </div>
  );
}