import React, { useEffect, useState } from 'react';
import { Droplets, Shield, Sparkles } from 'lucide-react';
import { fetchRecommendedProducts } from '../../services/marketplace';
import ProductGrid from './ProductGrid';
import type { Product } from '../../types/Product';

interface HairProfile {
  type: string;
  gender: string;
  condition: string;
}

interface HairRecommendationsProps {
  profile: HairProfile;
}

const recommendations = {
  hydrated: {
    title: 'Cabelo Hidratado',
    description: 'Seu cabelo está saudável! Continue com sua rotina atual.',
    tips: [
      'Mantenha a hidratação regular',
      'Use protetor térmico antes de utilizar ferramentas de calor',
      'Faça máscara capilar quinzenalmente'
    ]
  },
  malnourished: {
    title: 'Cabelo Desnutrido',
    description: 'Seu cabelo precisa de nutrientes específicos.',
    tips: [
      'Utilize produtos ricos em proteínas',
      'Faça hidratação semanal',
      'Considere suplementação vitamínica'
    ]
  },
  dry: {
    title: 'Cabelo Ressecado',
    description: 'Seu cabelo precisa de hidratação intensiva.',
    tips: [
      'Use leave-in diariamente',
      'Evite água muito quente',
      'Faça umectação noturna'
    ]
  },
  porous: {
    title: 'Cabelo Poroso',
    description: 'Seu cabelo precisa de tratamento para selar as cutículas.',
    tips: [
      'Use produtos com queratina',
      'Faça hidratação com óleo quente',
      'Evite procedimentos químicos'
    ]
  }
};

export default function HairRecommendations({ profile }: HairRecommendationsProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const recommendation = recommendations[profile.condition as keyof typeof recommendations];

  useEffect(() => {
    async function loadProducts() {
      try {
        const recommendedProducts = await fetchRecommendedProducts(
          profile.type,
          profile.condition
        );
        setProducts(recommendedProducts);
      } catch (error) {
        console.error('Failed to load products:', error);
      } finally {
        setLoading(false);
      }
    }

    loadProducts();
  }, [profile]);

  return (
    <div className="space-y-12">
      <div className="space-y-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold mb-2">{recommendation.title}</h2>
          <p className="text-gray-600">{recommendation.description}</p>
        </div>

        <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-6 rounded-xl">
          <div className="flex items-center gap-4 mb-4">
            <Droplets className="w-8 h-8 text-pink-500" />
            <h3 className="text-xl font-semibold">Recomendações Personalizadas</h3>
          </div>
          <ul className="space-y-3">
            {recommendation.tips.map((tip, index) => (
              <li key={index} className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-purple-500 flex-shrink-0" />
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-bold">Produtos Recomendados</h3>
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Sparkles className="w-4 h-4" />
            <span>Selecionados especialmente para você</span>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin w-8 h-8 border-4 border-pink-500 border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-gray-600">Carregando produtos recomendados...</p>
          </div>
        ) : (
          <ProductGrid products={products} />
        )}
      </div>
    </div>
  );
}