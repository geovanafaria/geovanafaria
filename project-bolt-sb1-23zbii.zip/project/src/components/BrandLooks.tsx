import React, { useState, useRef } from 'react';
import { Heart, Bookmark, Tag, ChevronLeft, ChevronRight } from 'lucide-react';
import { brandLooks } from '../data/brandLooks';
import type { Look } from '../types/Look';

interface BrandLooksProps {
  selectedBrand: string;
}

export default function BrandLooks({ selectedBrand }: BrandLooksProps) {
  const [selectedTag, setSelectedTag] = useState<string | null>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const looks = brandLooks[selectedBrand] || [];

  if (looks.length === 0) return null;

  const allTags = Array.from(
    new Set(looks.flatMap((look) => look.tags))
  ).sort();

  const filteredLooks = selectedTag
    ? looks.filter((look) => look.tags.includes(selectedTag))
    : looks;

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const scrollAmount = 400;
      const newScrollLeft = direction === 'left'
        ? sliderRef.current.scrollLeft - scrollAmount
        : sliderRef.current.scrollLeft + scrollAmount;
      
      sliderRef.current.scrollTo({
        left: newScrollLeft,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="space-y-6">
      {allTags.length > 0 && (
        <div className="flex flex-wrap gap-2 pb-4">
          {allTags.map((tag) => (
            <button
              key={tag}
              onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium flex items-center gap-1.5 transition-colors
                ${selectedTag === tag
                  ? 'bg-black text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
            >
              <Tag className="w-3.5 h-3.5" />
              {tag}
            </button>
          ))}
        </div>
      )}

      <div className="relative group">
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-white/90 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity disabled:opacity-0"
          disabled={!sliderRef.current || sliderRef.current.scrollLeft === 0}
        >
          <ChevronLeft className="w-6 h-6 text-gray-700" />
        </button>

        <div
          ref={sliderRef}
          className="flex overflow-x-auto gap-6 pb-4 snap-x snap-mandatory scrollbar-hide"
          style={{ scrollbarWidth: 'none' }}
        >
          {filteredLooks.map((look) => (
            <div
              key={look.id}
              className="flex-none w-[300px] md:w-[350px] snap-start bg-white rounded-xl overflow-hidden shadow-lg group/card"
            >
              <div className="relative">
                <img
                  src={look.image}
                  alt={look.description}
                  className="w-full h-[400px] object-cover transition-transform duration-300 group-hover/card:scale-105"
                />
                <div className="absolute top-4 right-4 flex space-x-2">
                  <button className="p-2 bg-white/90 rounded-full shadow-md hover:bg-white transition-colors">
                    <Heart className="w-5 h-5 text-gray-700" />
                  </button>
                  <button className="p-2 bg-white/90 rounded-full shadow-md hover:bg-white transition-colors">
                    <Bookmark className="w-5 h-5 text-gray-700" />
                  </button>
                </div>
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                  <h3 className="font-semibold text-lg text-white">{look.description}</h3>
                  <p className="text-white/90">{look.brand}</p>
                </div>
              </div>
              <div className="p-4">
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center text-gray-500">
                    <Heart className="w-4 h-4 mr-1" />
                    <span>{look.likes.toLocaleString()} likes</span>
                  </div>
                  <span className="text-lg font-bold text-pink-600">{look.price}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {look.tags.map((tag) => (
                    <span
                      key={tag}
                      className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 p-2 bg-white/90 rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ChevronRight className="w-6 h-6 text-gray-700" />
        </button>
      </div>
    </div>
  );
}