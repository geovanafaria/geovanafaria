import React from 'react';
import { useStylePreferences } from '../context/StylePreferencesContext';
import { useAuthStore } from '../stores/authStore';
import { ArrowLeft, LogOut } from 'lucide-react';
import Header from './Header';
import Navigation from './Navigation';
import FashionSection from '../sections/FashionSection';
import HairSection from '../sections/HairSection';
import SkinSection from '../sections/SkinSection';
import CalendarSection from '../sections/CalendarSection';
import LandingPage from './LandingPage';

interface MainAppProps {
  initialSection: string;
}

export default function MainApp({ initialSection }: MainAppProps) {
  const { hasCompletedOnboarding } = useStylePreferences();
  const [activeSection, setActiveSection] = React.useState(initialSection);
  const { logout } = useAuthStore();

  const handleBack = () => {
    setActiveSection('');
  };

  const handleLogout = () => {
    if (confirm('Tem certeza que deseja sair?')) {
      logout();
    }
  };

  if (!activeSection) {
    return <LandingPage onSectionSelect={setActiveSection} />;
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Navigation activeSection={activeSection} onSectionChange={setActiveSection} />
      
      {/* Back Button and Logout */}
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <button
          onClick={handleBack}
          className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="font-medium">Voltar</span>
        </button>

        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 text-red-600 hover:text-red-700 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sair</span>
        </button>
      </div>

      <main className="max-w-7xl mx-auto px-4">
        {activeSection === 'fashion' && <FashionSection />}
        {activeSection === 'hair' && <HairSection />}
        {activeSection === 'skin' && <SkinSection />}
        {activeSection === 'calendar' && <CalendarSection />}
      </main>
    </div>
  );
}