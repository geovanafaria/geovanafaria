import React from 'react';
import { format } from 'date-fns';
import { X, Calendar, Clock, Tag } from 'lucide-react';
import { useCalendarStore } from '../../stores/calendarStore';

interface EventDetailsProps {
  event: any;
  onClose: () => void;
}

export default function EventDetails({ event, onClose }: EventDetailsProps) {
  const removeEvent = useCalendarStore((state) => state.removeEvent);

  const handleDelete = () => {
    if (confirm('Tem certeza que deseja excluir este evento?')) {
      removeEvent(event.id);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold">{event.title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="flex items-center gap-2 text-gray-600">
            <Calendar className="w-5 h-5" />
            <span>
              {format(event.start, 'dd/MM/yyyy')} - {format(event.end, 'dd/MM/yyyy')}
            </span>
          </div>

          <div className="flex items-center gap-2 text-gray-600">
            <Tag className="w-5 h-5" />
            <span className="capitalize">{event.extendedProps.category}</span>
          </div>

          {event.extendedProps.description && (
            <p className="text-gray-700">{event.extendedProps.description}</p>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <button
              onClick={handleDelete}
              className="px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg"
            >
              Excluir
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-900"
            >
              Fechar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}