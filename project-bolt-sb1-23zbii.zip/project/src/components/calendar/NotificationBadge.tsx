import React from 'react';

export default function NotificationBadge() {
  return (
    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
  );
}