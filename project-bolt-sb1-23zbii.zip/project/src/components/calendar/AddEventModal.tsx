import React, { useState } from 'react';
import { format } from 'date-fns';
import { X } from 'lucide-react';
import { useCalendarStore } from '../../stores/calendarStore';

interface AddEventModalProps {
  selectedDate: Date | null;
  onClose: () => void;
  defaultValues?: {
    title?: string;
    description?: string;
    category?: 'fashion' | 'hair' | 'skin';
  };
}

export default function AddEventModal({ 
  selectedDate, 
  onClose,
  defaultValues = {}
}: AddEventModalProps) {
  const addEvent = useCalendarStore((state) => state.addEvent);
  const [formData, setFormData] = useState({
    title: defaultValues.title || '',
    description: defaultValues.description || '',
    category: defaultValues.category || 'fashion',
    start: selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '',
    end: selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '',
    reminder: true
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addEvent({
      ...formData,
      start: new Date(formData.start),
      end: new Date(formData.end),
      category: formData.category as 'fashion' | 'hair' | 'skin'
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-bold">Novo Evento</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Título
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Categoria
            </label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
            >
              <option value="fashion">Moda</option>
              <option value="hair">Cabelo</option>
              <option value="skin">Pele</option>
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Início
              </label>
              <input
                type="date"
                value={formData.start}
                onChange={(e) => setFormData({ ...formData, start: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Data Fim
              </label>
              <input
                type="date"
                value={formData.end}
                onChange={(e) => setFormData({ ...formData, end: e.target.value })}
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Descrição
            </label>
            <textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
              rows={3}
            />
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="reminder"
              checked={formData.reminder}
              onChange={(e) => setFormData({ ...formData, reminder: e.target.checked })}
              className="rounded text-pink-500 focus:ring-pink-500"
            />
            <label htmlFor="reminder" className="ml-2 text-sm text-gray-700">
              Receber notificação
            </label>
          </div>

          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-900"
            >
              Salvar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}