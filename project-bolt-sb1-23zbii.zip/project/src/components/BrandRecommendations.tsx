import React, { useState } from 'react';
import { useStylePreferences } from '../context/StylePreferencesContext';
import { styleBrands } from '../data/styleBrands';
import BrandLooks from './BrandLooks';

export default function BrandRecommendations() {
  const { preferences } = useStylePreferences();
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const recommendedBrands = preferences.styleChoices.flatMap(style => styleBrands[style] || []);

  if (recommendedBrands.length === 0) return null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="text-2xl font-bold mb-6">Recommended Brands for Your Style</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {recommendedBrands.map((brand, index) => (
          <div
            key={index}
            className={`bg-white rounded-xl overflow-hidden shadow-md transition-all cursor-pointer
              ${selectedBrand === brand.name 
                ? 'ring-2 ring-pink-500 shadow-lg scale-[1.02]' 
                : 'hover:shadow-lg hover:scale-[1.01]'}`}
            onClick={() => setSelectedBrand(selectedBrand === brand.name ? null : brand.name)}
          >
            <div className="h-48 overflow-hidden">
              <img
                src={brand.logo}
                alt={brand.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <h3 className="text-xl font-semibold mb-2">{brand.name}</h3>
              <p className="text-gray-600">{brand.description}</p>
            </div>
          </div>
        ))}
      </div>

      {selectedBrand && (
        <div className="mt-8">
          <div className="border-b border-gray-200 mb-6">
            <h3 className="text-xl font-bold pb-4">Featured Looks from {selectedBrand}</h3>
          </div>
          <BrandLooks selectedBrand={selectedBrand} />
        </div>
      )}
    </div>
  );
}