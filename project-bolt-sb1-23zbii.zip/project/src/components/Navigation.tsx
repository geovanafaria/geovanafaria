import React from 'react';
import { Shirt, Scissors, Sparkles, Calendar } from 'lucide-react';

interface NavigationProps {
  activeSection: string;
  onSectionChange: (section: string) => void;
}

const sections = [
  { id: 'fashion', label: 'Moda', icon: Shirt, color: 'rose' },
  { id: 'hair', label: 'Cabelo', icon: Scissors, color: 'violet' },
  { id: 'skin', label: 'Skin Care', icon: Sparkles, color: 'amber' },
  { id: 'calendar', label: 'Calendário', icon: Calendar, color: 'emerald' },
];

const colorMap = {
  rose: 'text-rose-500 border-rose-500',
  violet: 'text-violet-500 border-violet-500',
  amber: 'text-amber-500 border-amber-500',
  emerald: 'text-emerald-500 border-emerald-500'
};

export default function Navigation({ activeSection, onSectionChange }: NavigationProps) {
  return (
    <nav className="sticky top-[73px] z-40 bg-white border-b">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex justify-around">
          {sections.map(({ id, label, icon: Icon, color }) => (
            <button
              key={id}
              onClick={() => onSectionChange(id)}
              className={`flex flex-col items-center py-4 px-6 transition-colors relative
                ${activeSection === id 
                  ? colorMap[color]
                  : 'text-gray-600 hover:text-gray-900'}`}
            >
              <Icon className="w-6 h-6 mb-1" />
              <span className="text-sm font-medium">{label}</span>
              {activeSection === id && (
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 ${colorMap[color].split(' ')[1]}`} />
              )}
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}