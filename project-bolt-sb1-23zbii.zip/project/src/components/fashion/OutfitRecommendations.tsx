import React from 'react';
import { Heart, Bookmark, Share2 } from 'lucide-react';

interface Outfit {
  id: string;
  image: string;
  title: string;
  description: string;
  style: string[];
  price: string;
}

const outfitsByStyle: Record<string, Outfit[]> = {
  minimal: [
    {
      id: 'min1',
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
      title: 'Conjunto Minimalista Casual',
      description: 'Blazer oversized branco com calça de alfaiataria',
      style: ['minimal', 'classic'],
      price: 'R$ 450,00'
    },
    {
      id: 'min2',
      image: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80',
      title: 'Look Monocromático',
      description: 'Conjunto total black com texturas',
      style: ['minimal', 'elegant'],
      price: 'R$ 380,00'
    }
  ],
  streetwear: [
    {
      id: 'str1',
      image: 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80',
      title: 'Urban Streetwear',
      description: 'Moletom oversized com calça cargo',
      style: ['streetwear', 'urban'],
      price: 'R$ 320,00'
    },
    {
      id: 'str2',
      image: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80',
      title: 'Street Casual',
      description: 'Jaqueta bomber com calça jogger',
      style: ['streetwear', 'casual'],
      price: 'R$ 290,00'
    }
  ],
  classic: [
    {
      id: 'cls1',
      image: 'https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=800&q=80',
      title: 'Elegância Clássica',
      description: 'Vestido midi com blazer estruturado',
      style: ['classic', 'elegant'],
      price: 'R$ 520,00'
    },
    {
      id: 'cls2',
      image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?auto=format&fit=crop&w=800&q=80',
      title: 'Business Casual',
      description: 'Camisa de seda com calça alfaiataria',
      style: ['classic', 'minimal'],
      price: 'R$ 480,00'
    }
  ],
  bohemian: [
    {
      id: 'boh1',
      image: 'https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=800&q=80',
      title: 'Boho Chic',
      description: 'Vestido longo estampado com franjas',
      style: ['bohemian', 'artistic'],
      price: 'R$ 390,00'
    },
    {
      id: 'boh2',
      image: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=800&q=80',
      title: 'Boho Casual',
      description: 'Saia midi floral com blusa solta',
      style: ['bohemian', 'casual'],
      price: 'R$ 280,00'
    }
  ],
  artistic: [
    {
      id: 'art1',
      image: 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?auto=format&fit=crop&w=800&q=80',
      title: 'Arte Contemporânea',
      description: 'Vestido assimétrico com estampa artística',
      style: ['artistic', 'avant-garde'],
      price: 'R$ 450,00'
    },
    {
      id: 'art2',
      image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80',
      title: 'Expressão Artística',
      description: 'Conjunto com mix de estampas e texturas',
      style: ['artistic', 'eclectic'],
      price: 'R$ 410,00'
    }
  ],
  urban: [
    {
      id: 'urb1',
      image: 'https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=800&q=80',
      title: 'Urban Style',
      description: 'Jaqueta jeans oversized com calça cargo',
      style: ['urban', 'streetwear'],
      price: 'R$ 340,00'
    },
    {
      id: 'urb2',
      image: 'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80',
      title: 'City Casual',
      description: 'Moletom cropped com calça wide leg',
      style: ['urban', 'casual'],
      price: 'R$ 260,00'
    }
  ]
};

interface OutfitRecommendationsProps {
  styles: string[];
}

export default function OutfitRecommendations({ styles }: OutfitRecommendationsProps) {
  const recommendedOutfits = styles.flatMap(style => 
    outfitsByStyle[style]?.slice(0, 2) || []
  ).slice(0, 6);

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Looks Recomendados para Você</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {recommendedOutfits.map((outfit) => (
          <div
            key={outfit.id}
            className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-all"
          >
            <div className="relative aspect-[4/5]">
              <img
                src={outfit.image}
                alt={outfit.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-4 right-4 flex space-x-2">
                <button className="p-2 bg-white/90 rounded-full shadow-md hover:bg-white transition-colors">
                  <Heart className="w-5 h-5 text-gray-700" />
                </button>
                <button className="p-2 bg-white/90 rounded-full shadow-md hover:bg-white transition-colors">
                  <Bookmark className="w-5 h-5 text-gray-700" />
                </button>
                <button className="p-2 bg-white/90 rounded-full shadow-md hover:bg-white transition-colors">
                  <Share2 className="w-5 h-5 text-gray-700" />
                </button>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-lg mb-1">{outfit.title}</h3>
              <p className="text-gray-600 text-sm mb-2">{outfit.description}</p>
              <div className="flex justify-between items-center">
                <div className="flex gap-2">
                  {outfit.style.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 bg-gray-100 text-gray-600 rounded-full text-xs"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                <span className="font-bold text-pink-600">{outfit.price}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}