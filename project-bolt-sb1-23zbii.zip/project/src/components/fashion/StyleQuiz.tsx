import React, { useState } from 'react';
import { ChevronRight } from 'lucide-react';

interface StyleQuizProps {
  onComplete: (styles: string[]) => void;
}

const styleOptions = [
  {
    id: 'minimal',
    label: 'Minimal & Clean',
    image: 'https://images.unsplash.com/photo-1608366550481-c05681f6e005?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'streetwear',
    label: 'Street Style',
    image: 'https://images.unsplash.com/photo-1523398002811-999ca8dec234?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'classic',
    label: 'Classic & Elegant',
    image: 'https://images.unsplash.com/photo-1490725263030-1f0521cec8ec?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'bohemian',
    label: 'Bohemian',
    image: 'https://images.unsplash.com/photo-1605763240000-7e93b172d754?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'contemporary',
    label: 'Contemporary',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'avant-garde',
    label: 'Avant-Garde',
    image: 'https://images.unsplash.com/photo-1512646605205-78422b7c7896?auto=format&fit=crop&w=800&q=80'
  }
];

const colorOptions = [
  {
    id: 'neutral',
    label: 'Neutral Tones',
    image: 'https://images.unsplash.com/photo-1564584217132-2271feaeb3c5?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'monochrome',
    label: 'Monochrome',
    image: 'https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'bold',
    label: 'Bold Colors',
    image: 'https://images.unsplash.com/photo-1549989476-69a92fa57c36?auto=format&fit=crop&w=800&q=80'
  }
];

const occasionOptions = [
  {
    id: 'casual',
    label: 'Casual',
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'workwear',
    label: 'Work',
    image: 'https://images.unsplash.com/photo-1487222477894-8943e31ef7b2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'evening',
    label: 'Evening',
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80'
  }
];

export default function StyleQuiz({ onComplete }: StyleQuizProps) {
  const [step, setStep] = useState(0);
  const [selectedStyles, setSelectedStyles] = useState<string[]>([]);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedOccasions, setSelectedOccasions] = useState<string[]>([]);

  const handleComplete = () => {
    setPreferences({
      styleChoices: selectedStyles,
      colorPalette: selectedColors,
      occasions: selectedOccasions,
    });
    setHasCompletedOnboarding(true);
  };

  const steps = [
    {
      title: "What's your style?",
      description: "Choose the styles that resonate with you the most",
      options: styleOptions,
      selected: selectedStyles,
      setSelected: setSelectedStyles,
    },
    {
      title: "Color preferences",
      description: "Select the color palettes you prefer",
      options: colorOptions,
      selected: selectedColors,
      setSelected: setSelectedColors,
    },
    {
      title: "Occasions",
      description: "What occasions do you want to see outfits for?",
      options: occasionOptions,
      selected: selectedOccasions,
      setSelected: setSelectedOccasions,
    },
  ];

  const currentStep = steps[step];

  const handleNext = () => {
    if (step === steps.length - 1) {
      handleComplete();
    } else {
      setStep(step + 1);
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center">
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">{currentStep.title}</h2>
        <p className="text-gray-600 mb-8">{currentStep.description}</p>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {currentStep.options.map((option) => (
            <button
              key={option.id}
              onClick={() => {
                const current = currentStep.selected;
                const updated = current.includes(option.id)
                  ? current.filter((item) => item !== option.id)
                  : [...current, option.id];
                currentStep.setSelected(updated);
              }}
              className={`relative aspect-square rounded-xl overflow-hidden group
                ${currentStep.selected.includes(option.id)
                  ? 'ring-4 ring-pink-500'
                  : 'ring-1 ring-gray-200'
                }`}
            >
              <img
                src={option.image}
                alt={option.label}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/40 flex items-end p-4">
                <span className="text-white font-medium">{option.label}</span>
              </div>
            </button>
          ))}
        </div>

        <button
          onClick={handleNext}
          disabled={currentStep.selected.length === 0}
          className={`mt-8 w-full py-3 px-4 rounded-full flex items-center justify-center space-x-2
            ${currentStep.selected.length > 0
              ? 'bg-black text-white hover:bg-gray-900'
              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
        >
          <span>{step === steps.length - 1 ? 'Complete' : 'Next'}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}