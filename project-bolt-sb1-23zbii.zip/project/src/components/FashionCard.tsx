import React from 'react';
import { Heart, Bookmark, Share2 } from 'lucide-react';

interface FashionCardProps {
  image: string;
  title: string;
  author: string;
  likes: number;
}

export default function FashionCard({ image, title, author, likes }: FashionCardProps) {
  return (
    <div className="relative group rounded-xl overflow-hidden">
      <img
        src={image}
        alt={title}
        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
      />
      
      <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <div className="absolute bottom-0 left-0 right-0 p-4">
          <h3 className="text-white font-medium text-lg mb-1">{title}</h3>
          <p className="text-gray-200 text-sm">{author}</p>
          
          <div className="flex items-center justify-between mt-3">
            <div className="flex items-center space-x-2">
              <Heart className="w-5 h-5 text-white" />
              <span className="text-white text-sm">{likes}</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <button className="p-2 hover:bg-white/20 rounded-full transition-colors">
                <Bookmark className="w-5 h-5 text-white" />
              </button>
              <button className="p-2 hover:bg-white/20 rounded-full transition-colors">
                <Share2 className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}