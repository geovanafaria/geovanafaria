interface Brand {
  name: string;
  description: string;
  logo: string;
}

interface StyleBrands {
  [key: string]: Brand[];
}

export const styleBrands: StyleBrands = {
  minimal: [
    {
      name: "COS",
      description: "Modern, functional pieces with clean lines",
      logo: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Uniqlo",
      description: "Essential clothing with minimalist design",
      logo: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80"
    }
  ],
  streetwear: [
    {
      name: "Supreme",
      description: "Iconic streetwear with cultural influence",
      logo: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Off-White",
      description: "High-end streetwear with artistic vision",
      logo: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80"
    }
  ],
  classic: [
    {
      name: "Ralph Lauren",
      description: "Timeless American luxury fashion",
      logo: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Burberry",
      description: "British luxury fashion house",
      logo: "https://images.unsplash.com/photo-1548126032-079a0fb0099d?auto=format&fit=crop&w=800&q=80"
    }
  ],
  bohemian: [
    {
      name: "Free People",
      description: "Bohemian fashion with artistic flair",
      logo: "https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=800&q=80"
    },
    {
      name: "Anthropologie",
      description: "Romantic and artistic bohemian style",
      logo: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce?auto=format&fit=crop&w=800&q=80"
    }
  ]
};