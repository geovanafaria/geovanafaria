import { Look } from '../types/Look';

export const brandLooks: Record<string, Look[]> = {
  "COS": [
    {
      id: "cos1",
      brand: "COS",
      image: "https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?auto=format&fit=crop&w=800&q=80",
      description: "Minimalist Autumn Ensemble",
      likes: 1234,
      price: "$289",
      tags: ["minimal", "autumn", "workwear"]
    },
    {
      id: "cos2",
      brand: "COS",
      image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80",
      description: "Modern Office Collection",
      likes: 892,
      price: "$345",
      tags: ["office", "minimal", "professional"]
    },
    {
      id: "cos3",
      brand: "COS",
      image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
      description: "Weekend Casual Edit",
      likes: 756,
      price: "$195",
      tags: ["casual", "minimal", "weekend"]
    }
  ],
  "Uniqlo": [
    {
      id: "uniqlo1",
      brand: "Uniqlo",
      image: "https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?auto=format&fit=crop&w=800&q=80",
      description: "Essential Basics Collection",
      likes: 2156,
      price: "$89",
      tags: ["basics", "minimal", "everyday"]
    },
    {
      id: "uniqlo2",
      brand: "Uniqlo",
      image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80",
      description: "Autumn Layers",
      likes: 1654,
      price: "$129",
      tags: ["layering", "autumn", "casual"]
    }
  ],
  "Supreme": [
    {
      id: "supreme1",
      brand: "Supreme",
      image: "https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80",
      description: "Urban Street Style",
      likes: 2341,
      price: "$420",
      tags: ["streetwear", "urban", "trendy"]
    },
    {
      id: "supreme2",
      brand: "Supreme",
      image: "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=800&q=80",
      description: "Streetwear Essential",
      likes: 1876,
      price: "$385",
      tags: ["essential", "streetwear", "casual"]
    }
  ],
  "Off-White": [
    {
      id: "offwhite1",
      brand: "Off-White",
      image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?auto=format&fit=crop&w=800&q=80",
      description: "Industrial Belt Collection",
      likes: 4532,
      price: "$890",
      tags: ["luxury", "streetwear", "accessories"]
    },
    {
      id: "offwhite2",
      brand: "Off-White",
      image: "https://images.unsplash.com/photo-1543076447-215ad9ba6923?auto=format&fit=crop&w=800&q=80",
      description: "Graphic Print Series",
      likes: 3298,
      price: "$570",
      tags: ["graphic", "statement", "urban"]
    }
  ]
};