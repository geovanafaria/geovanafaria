import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Product } from '../types/Product';
import type { Look } from '../types/Look';

interface WishlistItem {
  id: string;
  type: 'product' | 'look';
  item: Product | Look;
  addedAt: Date;
}

interface WishlistState {
  items: WishlistItem[];
  addItem: (type: 'product' | 'look', item: Product | Look) => void;
  removeItem: (id: string) => void;
  isInWishlist: (id: string) => boolean;
}

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (type, item) => {
        if (!get().isInWishlist(item.id)) {
          set((state) => ({
            items: [
              ...state.items,
              {
                id: item.id,
                type,
                item,
                addedAt: new Date(),
              },
            ],
          }));
        }
      },
      removeItem: (id) =>
        set((state) => ({
          items: state.items.filter((item) => item.id !== id),
        })),
      isInWishlist: (id) =>
        get().items.some((item) => item.id === id),
    }),
    {
      name: 'wishlist-store',
    }
  )
);