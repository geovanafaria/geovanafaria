import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { addDays, format } from 'date-fns';

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  description: string;
  category: 'fashion' | 'hair' | 'skin';
  backgroundColor: string;
  reminder: boolean;
}

interface Notification {
  id: string;
  eventId: string;
  title: string;
  message: string;
  date: Date;
  read: boolean;
}

interface CalendarStore {
  events: CalendarEvent[];
  notifications: Notification[];
  notificationsEnabled: boolean;
  addEvent: (event: Omit<CalendarEvent, 'id'>) => void;
  removeEvent: (id: string) => void;
  updateEvent: (id: string, event: Partial<CalendarEvent>) => void;
  addNotification: (notification: Omit<Notification, 'id'>) => void;
  markNotificationAsRead: (id: string) => void;
  toggleNotifications: () => void;
}

const categoryColors = {
  fashion: '#EC4899',
  hair: '#8B5CF6',
  skin: '#F59E0B'
};

export const useCalendarStore = create<CalendarStore>()(
  persist(
    (set) => ({
      events: [],
      notifications: [],
      notificationsEnabled: true,

      addEvent: (event) => set((state) => {
        const newEvent = {
          ...event,
          id: crypto.randomUUID(),
          backgroundColor: categoryColors[event.category]
        };

        if (event.reminder) {
          const notification: Omit<Notification, 'id'> = {
            eventId: newEvent.id,
            title: 'Lembrete',
            message: `Não esqueça: ${event.title}`,
            date: event.start,
            read: false
          };
          state.addNotification(notification);
        }

        return { events: [...state.events, newEvent] };
      }),

      removeEvent: (id) => set((state) => ({
        events: state.events.filter((event) => event.id !== id),
        notifications: state.notifications.filter((notif) => notif.eventId !== id)
      })),

      updateEvent: (id, updatedEvent) => set((state) => ({
        events: state.events.map((event) =>
          event.id === id ? { ...event, ...updatedEvent } : event
        )
      })),

      addNotification: (notification) => set((state) => ({
        notifications: [
          ...state.notifications,
          { ...notification, id: crypto.randomUUID() }
        ]
      })),

      markNotificationAsRead: (id) => set((state) => ({
        notifications: state.notifications.map((notif) =>
          notif.id === id ? { ...notif, read: true } : notif
        )
      })),

      toggleNotifications: () => set((state) => ({
        notificationsEnabled: !state.notificationsEnabled
      }))
    }),
    {
      name: 'calendar-store'
    }
  )
);