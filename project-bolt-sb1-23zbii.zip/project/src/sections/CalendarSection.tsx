import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import { format } from 'date-fns';
import { Bell, BellOff, Plus } from 'lucide-react';
import { useCalendarStore } from '../stores/calendarStore';
import AddEventModal from '../components/calendar/AddEventModal';
import NotificationBadge from '../components/calendar/NotificationBadge';
import EventDetails from '../components/calendar/EventDetails';
import PageTransition from '../components/PageTransition';

export default function CalendarSection() {
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<any>(null);
  const { events, notifications, toggleNotifications, notificationsEnabled } = useCalendarStore();

  const handleDateClick = (arg: any) => {
    setSelectedDate(arg.date);
    setShowAddModal(true);
  };

  const handleEventClick = (arg: any) => {
    setSelectedEvent(arg.event);
  };

  return (
    <PageTransition>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Seu Calendário de Beleza</h2>
            <p className="text-gray-600">Gerencie sua rotina de cuidados</p>
          </div>
          
          <div className="flex items-center gap-4">
            <button
              onClick={() => toggleNotifications()}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors"
            >
              {notificationsEnabled ? (
                <>
                  <Bell className="w-5 h-5" />
                  <span>Notificações Ativas</span>
                </>
              ) : (
                <>
                  <BellOff className="w-5 h-5" />
                  <span>Notificações Desativadas</span>
                </>
              )}
            </button>
            
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black text-white hover:bg-gray-900 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Novo Evento</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md p-6">
          <FullCalendar
            plugins={[dayGridPlugin, interactionPlugin]}
            initialView="dayGridMonth"
            locale="pt-br"
            events={events}
            dateClick={handleDateClick}
            eventClick={handleEventClick}
            headerToolbar={{
              left: 'prev,next today',
              center: 'title',
              right: 'dayGridMonth'
            }}
            height="auto"
            eventContent={(arg) => (
              <div className="flex items-center gap-2 p-1">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: arg.event.backgroundColor }}
                />
                <span className="text-sm truncate">{arg.event.title}</span>
                {notifications.some(n => n.eventId === arg.event.id) && (
                  <NotificationBadge />
                )}
              </div>
            )}
          />
        </div>

        {showAddModal && (
          <AddEventModal
            selectedDate={selectedDate}
            onClose={() => {
              setShowAddModal(false);
              setSelectedDate(null);
            }}
          />
        )}

        {selectedEvent && (
          <EventDetails
            event={selectedEvent}
            onClose={() => setSelectedEvent(null)}
          />
        )}
      </div>
    </PageTransition>
  );
}