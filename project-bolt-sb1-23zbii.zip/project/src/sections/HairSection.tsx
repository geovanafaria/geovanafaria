import React, { useState } from 'react';
import { Droplets, Wind, Thermometer, Shield } from 'lucide-react';
import HairTypeQuiz from '../components/hair/HairTypeQuiz';
import FloatingHairQuiz from '../components/hair/FloatingHairQuiz';
import HairRecommendations from '../components/hair/HairRecommendations';
import PageTransition from '../components/PageTransition';

export default function HairSection() {
  const [hairProfile, setHairProfile] = useState({
    type: '',
    gender: '',
    condition: ''
  });

  const [quizStep, setQuizStep] = useState<'type' | 'floating' | 'complete'>('type');

  const handleHairTypeSubmit = (type: string, gender: string) => {
    setHairProfile(prev => ({ ...prev, type, gender }));
    setQuizStep('floating');
  };

  const handleFloatingTestSubmit = (condition: string) => {
    setHairProfile(prev => ({ ...prev, condition }));
    setQuizStep('complete');
  };

  return (
    <PageTransition className="max-w-4xl mx-auto py-8 px-4">
      {quizStep === 'type' && (
        <HairTypeQuiz onSubmit={handleHairTypeSubmit} />
      )}
      
      {quizStep === 'floating' && (
        <FloatingHairQuiz onSubmit={handleFloatingTestSubmit} />
      )}
      
      {quizStep === 'complete' && (
        <HairRecommendations profile={hairProfile} />
      )}
    </PageTransition>
  );
}