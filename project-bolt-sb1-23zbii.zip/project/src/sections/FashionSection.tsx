import React from 'react';
import { useStylePreferences } from '../context/StylePreferencesContext';
import CategoryBar from '../components/CategoryBar';
import BrandRecommendations from '../components/BrandRecommendations';
import FashionGrid from '../components/FashionGrid';
import StyleQuiz from '../components/fashion/StyleQuiz';
import OutfitRecommendations from '../components/fashion/OutfitRecommendations';
import PageTransition from '../components/PageTransition';

export default function FashionSection() {
  const { hasCompletedOnboarding, preferences, setPreferences, setHasCompletedOnboarding } = useStylePreferences();
  const [showQuiz, setShowQuiz] = React.useState(!hasCompletedOnboarding);

  const handleQuizComplete = (styles: string[]) => {
    setPreferences(prev => ({
      ...prev,
      styleChoices: styles
    }));
    setHasCompletedOnboarding(true);
    setShowQuiz(false);
  };

  if (showQuiz) {
    return (
      <PageTransition>
        <StyleQuiz onComplete={handleQuizComplete} />
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <div>
        <CategoryBar />
        <div className="max-w-7xl mx-auto px-4">
          <div className="hidden md:block">
            <OutfitRecommendations styles={preferences.styleChoices} />
            <BrandRecommendations />
          </div>
          <FashionGrid />
        </div>
      </div>
    </PageTransition>
  );
}