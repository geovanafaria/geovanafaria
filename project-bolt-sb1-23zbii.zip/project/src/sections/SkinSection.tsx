import React, { useState } from 'react';
import SkinTypeQuiz from '../components/skin/SkinTypeQuiz';
import SkinRecommendations from '../components/skin/SkinRecommendations';
import PageTransition from '../components/PageTransition';

export default function SkinSection() {
  const [skinProfile, setSkinProfile] = useState<{
    type: string;
    concerns: string[];
    sensitivity: string;
  } | null>(null);

  if (!skinProfile) {
    return (
      <PageTransition>
        <SkinTypeQuiz onComplete={setSkinProfile} />
      </PageTransition>
    );
  }

  return (
    <PageTransition>
      <SkinRecommendations profile={skinProfile} />
    </PageTransition>
  );
}