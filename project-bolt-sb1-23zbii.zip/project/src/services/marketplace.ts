import type { Product } from '../types/Product';

export async function fetchRecommendedProducts(
  hairType: string,
  hairCondition: string
): Promise<Product[]> {
  const products: Product[] = [
    {
      id: '1',
      name: 'Shampoo Hidratação Profunda',
      brand: 'Pantene',
      price: 29.90,
      rating: 4.5,
      reviews: 1234,
      image: 'https://images.unsplash.com/photo-1526947425960-945c6e72858f?auto=format&fit=crop&w=800&q=80',
      description: 'Shampoo para hidratação profunda dos fios',
      marketplace: 'amazon',
      marketplaceUrl: 'https://amazon.com',
      category: ['shampoo', 'hidratação'],
      hairTypes: ['straight', 'wavy', 'curly'],
      hairConditions: ['dry', 'porous']
    },
    {
      id: '2',
      name: 'Máscara de Tratamento Intensivo',
      brand: 'Kerastase',
      price: 189.90,
      rating: 4.8,
      reviews: 856,
      image: 'https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=800&q=80',
      description: 'Máscara de tratamento para reconstrução capilar',
      marketplace: 'google',
      marketplaceUrl: 'https://shopping.google.com',
      category: ['máscara', 'tratamento'],
      hairTypes: ['all'],
      hairConditions: ['malnourished', 'dry']
    },
    {
      id: '3',
      name: 'Óleo Reparador',
      brand: 'L\'Oréal',
      price: 59.90,
      rating: 4.6,
      reviews: 2341,
      image: 'https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?auto=format&fit=crop&w=800&q=80',
      description: 'Óleo reparador para pontas duplas',
      marketplace: 'mercadolivre',
      marketplaceUrl: 'https://mercadolivre.com.br',
      category: ['óleo', 'reparação'],
      hairTypes: ['all'],
      hairConditions: ['dry', 'porous']
    }
  ];

  return products.filter(product => 
    (product.hairTypes.includes(hairType) || product.hairTypes.includes('all')) &&
    product.hairConditions.includes(hairCondition)
  );
}