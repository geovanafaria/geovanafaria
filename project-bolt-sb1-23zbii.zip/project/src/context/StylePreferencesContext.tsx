import React, { createContext, useContext, useState } from 'react';

interface StylePreferences {
  styleChoices: string[];
  colorPalette: string[];
  occasions: string[];
}

interface StylePreferencesContextType {
  preferences: StylePreferences;
  setPreferences: React.Dispatch<React.SetStateAction<StylePreferences>>;
  hasCompletedOnboarding: boolean;
  setHasCompletedOnboarding: React.Dispatch<React.SetStateAction<boolean>>;
}

const StylePreferencesContext = createContext<StylePreferencesContextType | undefined>(undefined);

export function StylePreferencesProvider({ children }: { children: React.ReactNode }) {
  const [preferences, setPreferences] = useState<StylePreferences>({
    styleChoices: [],
    colorPalette: [],
    occasions: [],
  });
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);

  return (
    <StylePreferencesContext.Provider
      value={{
        preferences,
        setPreferences,
        hasCompletedOnboarding,
        setHasCompletedOnboarding,
      }}
    >
      {children}
    </StylePreferencesContext.Provider>
  );
}

export function useStylePreferences() {
  const context = useContext(StylePreferencesContext);
  if (context === undefined) {
    throw new Error('useStylePreferences must be used within a StylePreferencesProvider');
  }
  return context;
}