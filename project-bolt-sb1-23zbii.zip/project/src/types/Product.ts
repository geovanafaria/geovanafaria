export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  rating: number;
  reviews: number;
  image: string;
  description: string;
  marketplace: 'amazon' | 'google' | 'mercadolivre';
  marketplaceUrl: string;
  category: string[];
  hairTypes: string[];
  hairConditions: string[];
}