export interface Look {
  id: string;
  brand: string;
  image: string;
  description: string;
  likes: number;
  price: string;
  tags: string[];
}